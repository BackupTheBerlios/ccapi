javadoc -windowtitle 'CCAPI JavaDocs' -splitindex -header '<b>CCAPI</b>' -bottom '(c) 2002-2004 Ulrich Staudinger' -sourcepath ./src -d ./javadoc CCAPI 


