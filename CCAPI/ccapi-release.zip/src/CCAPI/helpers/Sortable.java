package CCAPI.helpers;


/**
 *         interface for comparing objects/sortable.
 */
public interface Sortable {
    public int compare(Object other);
}
